# Agentic Restaurant Guest Simulation for Testing Ordering Systems

## Overview

This framework provides automated testing for ordering systems through agentic restaurant guest simulation. It creates realistic customer personas that interact with your ordering system to validate functionality, user experience, and edge cases. The system uses multiple specialized AI agents built with Pydantic AI to simulate human-like ordering behavior and comprehensive test coverage.

## Architecture

Multi-agent system orchestrating realistic restaurant guest simulation:

![Validation Agent Architecture](./Validation%20Agent%20Architecture.jpg)

### Core Agentic Components

- **Guest Agent** (`agents/guest_agent.py`) - Main conversational agent simulating customer behavior
- **Order Tracking Agent** (`agents/order_tracking_agent.py`) - Monitors order state and progress
- **Message Generation Agent** (`agents/message_generation_agent.py`) - Controls conversation style and tone
- **Configuration** (`agents/config.py`, `agents/ablation_config.py`) - Model settings and behavioral parameters

### Experiments & Evaluation

- **Experiment Runners** (`experiments/exp1-5/`) - Different test configurations and ablation studies
- **Evaluation Framework** (`evaluations/`) - Metrics calculation, state extraction, and statistical analysis
- **Ablation Analysis** (`evaluations/ablation_analyzer.py`) - Component impact assessment

## Installation

```bash
# Install uv package manager
pip install uv

# Sync dependencies
uv sync

# Set up environment variables
cp .env.example .env  # Add your API keys
```

Add the required keys in your `.env` file:

```
OPENAI_API_KEY=<YOUR-API-KEY>
OPENAI_MODEL=gpt-4o
```


## Usage

### Running Guest Simulations

```bash
# Run with agent-based simulation
cd scripts
uv run run_validation_conversation_with_agent.py

# Run with LLM-based simulation  
uv run run_validation_conversation_with_llm.py
```

Configure test parameters in script headers:
- `NUM_TEST_CASES` - Number of unique personas
- `NUM_RUNS_PER_TEST_CASE` - Iterations per persona

### Test Case Data

Test cases include personas and target orders from `test_case_generation/data/`:
- `personas.json` - Customer personalities and behaviors
- `menu.json` - Restaurant menu structure
- `order_test_cases.json` - Predefined ordering scenarios



## Output & Analysis

### Conversation Logs
Logs saved to `validation_conversation_logs/` and experiment folders:
- Message history with timestamps
- Role identification and conversation flow
- Tool call latencies and performance metrics
- Order state progression

### Evaluation Metrics
The framework tracks:
- **Order Accuracy** - Correct items, quantities, and modifications
- **Conversation Quality** - Natural flow and persona adherence  
- **System Performance** - Response times and tool execution latencies
- **Edge Case Handling** - Robustness to unusual requests

### Statistical Analysis
Run comprehensive evaluation:
```bash
cd evaluations
uv run run_ablation_analysis.py
```

Generates:
- `results/summary_statistics.csv` - Aggregate metrics
- `results/statistical_report.json` - Detailed analysis
- `results/figures/` - Visualization plots

## Paper & Research

Research paper in progress at `paper/draft/`. The work explores using agentic simulation for comprehensive testing of conversational ordering systems.

## Contributing

This project is actively developed. Key areas for contribution:
- Additional persona types and test scenarios
- Integration with more ordering platforms
- Enhanced evaluation metrics
- Performance optimizations

